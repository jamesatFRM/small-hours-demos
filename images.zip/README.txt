FRAMEPACK DELIVERY

6 delivered image versions / 2 included source images / 0 excluded source images / 0 failed image versions

Primary delivery: 2400px, image/jpeg, quality ceiling 85, full composition, 400 KB cap
Web & portfolio: 1600px, image/webp, quality ceiling 78, full composition, 400 KB cap
Social square: 1080px, image/jpeg, quality ceiling 90, square white padding, 400 KB cap

Primary files are in images/. Extra versions have named folders. All versions use the same image order and numbering; filenames may differ by extension. See manifest.csv for actual bytes, quality and ZIP paths, and batch-summary.csv for every failure. The recipe JSON restores settings only; reselect and order source images when repeating a job.

1 KB = 1024 bytes. Budgets keep dimensions fixed, lower quality no further than 40, and reject files that cannot meet the cap. Image content is never enlarged; a padded canvas can be larger than a small original.
Original files are unchanged. Metadata is omitted; transparency is flattened onto white. Not a color-managed print or archival export.
